<?php
# MetInfo Enterprise Content Management System
# Copyright (C) MetInfo Co.,Ltd (http://www.metinfo.cn). All rights reserved.
defined('IN_MET') or exit('No permission');
$head_tab[0]['title']=$word['indexfeedbackm'];
$head_tab[1]['title']=$word['columnmfeedback'];
$head_tab[2]['title']=$word['fdincTitle'];
?>
<include file="pub/form_head_tab"/>