<div class="met-import text-center">
  <button class="btn import1">{$word.webupate10}</button>
  <button class="btn ml-4 btn-primary import2">{$word.webupate9}</button>
</div>
