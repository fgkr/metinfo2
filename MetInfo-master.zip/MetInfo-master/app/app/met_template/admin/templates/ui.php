<div class="alert alert-primary">{$word.met_template_delettemplatesinfo}</div>
<div class="met-template-container">
 
</div>